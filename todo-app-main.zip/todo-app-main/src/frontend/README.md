## Requirements <a name="requirements"></a>

This sample application requires the following to be installed/enabled on your machine:

* a simple web server
* access to the apiEndpoint (url in app.js)
* * Don't forget to edit it

 
